/*	Documentation
	STM32FXXXϵ�� ����SWD������
	ȫ������������������б��
	���ݳ����Сѡ�����������С
	Ŀǰ֧��F0 F1 F3 F4 F7 H7
	����֤F0 F1 F4 ����������ʵ��û����֤
	оƬ�ͺ�ѡ�� SWD_opt.c/ ����Select_algo�����޸�
*/

/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"
#include "key.h"
#include "led.h"
#include "oled.h"
#include "ff.h"
#include "flash_blob.h"
#include "offline.h"
#include "hex2bin.h"
#include "stmflash.h"
#include "sys.h"
#include "delay.h"
#include "usart.h"


FRESULT Res;
FIL fnew; 											/* file objects */
FATFS fs;											/* FatFs�ļ�ϵͳ���� */
DIR DirInfo;										/* Ŀ¼��Ϣ */
FILINFO FileInfo;									/* �ļ���Ϣ */
int8_t name_cnt = 0;								/* �ļ����� */
int8_t csvname_cnt = 0;								/* �ļ����� */
BYTE work[FF_MAX_SS];           					/* FatFs�ļ��������� */
char Name_Buffer[20][20];      						/* �ļ��� */
char csvName_Buffer[20][20];      					/* �ļ��� */
int8_t Select_file = 0;								/* ѡ�������ļ� */
int8_t Select_fdata = 5;							/* ������С */
uint32_t flash_addr = 0x08000000;

uint8_t mode=0;
uint8_t Mode_Flash = 0;
//stmf4xx flash �����ڴ��ַ
uint32_t stmf4xxxG[12] = {0x08000000,0x08004000,0x08008000,0x0800C000,0x08010000,0x08020000,0x08040000,0x08060000,0x08080000,0x080A0000,0x080C0000,0x080E0000};
char flashsize[][6] = {"16k ","32k ","48k ","64k ","128k","256k","384k","512k","640k","768k","896k","ship",};

int main(void)
{
	uint8_t RES_FS = 0;
	uint8_t addr[4];
  HAL_Init();
  SystemClock_Config();
	delay_init(72);               		//��ʼ����ʱ����
	uart_init(4800);					//��ʼ������
	OLED_Init();
	MX_USB_DEVICE_Init();
	MX_KEY_Init();
	MX_LED_Init();

	flash_addr = 0x08000000;
	
	//FATFS�ļ�ϵͳ����
	algo_init();															//�����㷨��ʼ��
	RES_FS = f_mount(&fs,"",1);												//�����ļ�ϵͳ
	if (RES_FS == FR_OK);
	else if (RES_FS == FR_NO_FILESYSTEM) 									//�������оƬ��û���ļ�ϵͳ
	{
		OLED_ShowString(0, 2, "Fatfs Format..", 12);
		f_mkfs("", 0, work, sizeof(work));
		OLED_ShowString(0, 2, "Format Finished", 12);
	}
	else
		OLED_ShowString(0, 2, "Fatfs Failed..", 12);
	
//	f_unlink("write.bin");
	//��ȡ�ļ������ļ��б�
	if (f_opendir(&DirInfo, (const TCHAR *)"0:") == FR_OK) 	//��ȡ��Ŀ¼���ļ���Ϣ
	{
		f_readdir(&DirInfo, &FileInfo);
		while (f_readdir(&DirInfo, &FileInfo) == FR_OK) 			//���ļ���Ϣ���ļ�״̬�ṹ����
		{
			if (!FileInfo.fname[0])
				break;
			strcpy(Name_Buffer[name_cnt], FileInfo.fname);
			strcpy(csvName_Buffer[csvname_cnt], FileInfo.fname);

			if(strstr(Name_Buffer[name_cnt], "BIN"))
			{
				name_cnt++;
				if(name_cnt>=20)																		//��ౣ��20���ļ���
					break;
			}

		}
	}
  while (1)
  {
		menu();
		//���ڽ��ճɹ�
		// if(USART_RX_STA&0x8000)
		// {					   
		// 	// len=USART_RX_STA&0x3fff;//�õ��˴ν��յ������ݳ���
		// 	// HAL_UART_Transmit(&UART1_Handler,(uint8_t*)USART_RX_BUF,len,1000);	//���ͽ��յ�������
		// 	// while(__HAL_UART_GET_FLAG(&UART1_Handler,UART_FLAG_TC)!=SET);		//�ȴ����ͽ���
		// 	printf("%s\n", (uint8_t*)USART_RX_BUF);
		// 	printf("\r\n\r\n");//���뻻��
		// 	USART_RX_STA=0;
		// }
  }
  /* USER CODE END 3 */
}

void menu(void)
{
	static uint8_t mode_status = 0;
	switch(mode)
	{
		case 0://����ѡ��
			select_function();
			break;
		case 1://��������ģʽ
			Downloader();
			break;
		case 2://flash���ص�ַ
			Select_excel();
			break;		
	}
	if(mode != mode_status)
	{
		mode_status = mode;
		OLED_Clear();
	}
}


void OLED_ShowMenu(uint8_t num)
{
	switch(num)
	{
		case 0:	//��������
			OLED_ShowCH(24,0,0);
			OLED_ShowCH(36,0,1);
			OLED_ShowCH(48,0,2);
			OLED_ShowCH(60,0,3);
						//д������
			OLED_ShowCH(24,2,14);
			OLED_ShowCH(36,2,15);
			OLED_ShowCH(48,2,16);
			OLED_ShowCH(60,2,17);
			break;
		
		case 1:	//�ļ�ѡ��
			OLED_ShowCH(0,0,8);
			OLED_ShowCH(12,0,9);
			OLED_ShowCH(24,0,10);
			OLED_ShowCH(36,0,11);
			break;
		
		case 2:	//��ַδʹ��
			OLED_ShowString(0,0,"FLASH",12);
			OLED_ShowCH(40,0,12);
			OLED_ShowCH(52,0,13);
			OLED_ShowCH(64,0,4);
			OLED_ShowCH(76,0,5);
			break;
		case 3:	//����ģʽ
			OLED_ShowCH(0,0,18);
			OLED_ShowCH(12,0,19);
			OLED_ShowCH(24,0,20);
			OLED_ShowCH(36,0,21);
			break;
	}
}

void select_function(void)
{
	static uint8_t t=1;
	uint8_t key;
	key = KEY_Scan();
	if(key == KEY0_PRES)
	{
		t++;
		if(t>2)
			t=1;
	}
	else if(key == KEY1_PRES)//������ҳ��
	{
		mode = 0;
		t = 1;
	}
	else if(key == KEY2_PRES)//ȷ��
	{
		mode = t;
		t = 1;
	}
	switch(t)
	{
		case 1:
			OLED_ShowString(0,2,"  ",12);
			OLED_ShowString(0,0,"->",12);
			break;
		case 2:
			OLED_ShowString(0,0,"  ",12);
			OLED_ShowString(0,2,"->",12);
			break;
	}
	OLED_ShowMenu(0);
}

void Downloader(void)
{		
	uint8_t key =0;
	key = KEY_Scan();
	if(key == KEY0_PRES)
	{
		Select_file++;
		OLED_ShowString(0,2,"                ",12);
	}
	else if(key == KEY1_PRES)//������ҳ��
		mode = 0;
	else if(key == KEY2_PRES)
		Auto_Fash();
	if(name_cnt == 0)
		Select_file = 0;
	else
	{
		if(Select_file>=name_cnt)
			Select_file=0;
		else if(Select_file<0)
			Select_file=name_cnt-1;
	}
	OLED_ShowMenu(1);
	OLED_ShowString(0,2,(uint8_t*)Name_Buffer[Select_file],12);
	if(name_cnt == 0)
		OLED_ShowNum(90,0,Select_file,2,12);
	else
		OLED_ShowNum(90,0,Select_file+1,2,12);
	OLED_ShowString(102,0,"/",12);
	OLED_ShowNum(114,0,name_cnt,2,12);
}


//ѡ��ģʽ ȫ�������� �Ȳ���
void Select_excel(void)
{
	// OLED_ShowString(0,2,(uint8_t*)csvName_Buffer[0],12);
	uint8_t key =0;
	key = KEY_Scan();
	if(key == KEY0_PRES)
	{
		Select_fdata++;
		if(Select_fdata>11)
			Select_fdata=0;
		OLED_ShowString(0,2,"                ",12);
	}
	else if(key == KEY1_PRES)//������ҳ��
		mode = 0;
	OLED_ShowMenu(3);
	OLED_ShowString(0,2,flashsize[Select_fdata],12);
}

void FlashAddr_Set(void)
{
	static uint8_t k=0,k1=0;
	static uint8_t setmode =0;
	uint8_t addr[8];
	uint8_t key=0,i;
	uint8_t ad[4];
	addr[7] = (flash_addr/0x01)%16; 
	addr[6] = (flash_addr/0x10)%16; 
	addr[5] = (flash_addr/0x100)%16; 
	addr[4] = (flash_addr/0x1000)%16; 
	addr[3] = (flash_addr/0x10000)%16; 
	addr[2] = (flash_addr/0x100000)%16; 
	addr[1] = (flash_addr/0x1000000)%16; 
	addr[0] = (flash_addr/0x10000000)%16; 
	OLED_ShowMenu(2);
	OLED_ShowString(0,2,"0x",12);
	
	while(1)
	{
		for(i=0;i<8;i++)
		{
			if(addr[i]<10)
				OLED_ShowChar(18+6*i,2,addr[i]+48,12);
			else
				OLED_ShowChar(18+6*i,2,addr[i]+65-10,12);
		}
		
		key = KEY_Scan();
		if(key == KEY0_PRES)
		{
			if(setmode == 0)
			{
				OLED_ShowString(18+6*k,3,"|",12);
				setmode = 1;
			}
			else if(setmode == 1)
			{
				addr[k]++;
				if(addr[k]>15)
					addr[k]=0;
			}
		}
		else if(key == KEY1_PRES)
		{
			if(setmode == 0)
			{
				mode = 0;
				break;
			}
			else if(setmode == 1)
			{
				k++;
				if(k>=8)
					k=0;	
			}
		}
		else if(key == KEY2_PRES)
		{
			if(setmode == 0)
			{
				flash_addr = 0;
				
				ad[0] = addr[0]<<4|addr[1];
				ad[1] = addr[2]<<4|addr[3];
				ad[2] = addr[4]<<4|addr[5];
				ad[3] = addr[6]<<4|addr[7];
				
				flash_addr = ((ad[0]<<8|ad[1])<<8|ad[2])<<8|ad[3];
				STMFLASH_Write(FLASH_SAVE_ADDR,(uint16_t *)ad,4);
				HAL_Delay(1000);
				mode = 0;
				k=0;
				break;
			}
			else if(setmode == 1)
			{
				setmode = 0;
				OLED_ShowString(18+6*k1,3," ",12);
			}
		}
		
		if(k1 != k)
		{
			OLED_ShowString(18+6*k1,3," ",12);
			OLED_ShowString(18+6*k,3,"|",12);
			k1 = k;
		}
	}
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL_DIV1_5;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}


/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

